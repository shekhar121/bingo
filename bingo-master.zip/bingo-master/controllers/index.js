var html = require('./html');
var api = require('./api');
var chat = require('./chat');

module.exports = {

	html: html,
	api : api,
	chat : chat

}
